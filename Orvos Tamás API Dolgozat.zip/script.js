let currentData = [];
let container = document.getElementById("container");
let mensClothingAveragePrice = 0;
let mensClothingCount = 0;
let womensClothingAveragePrice = 0;
let womensClothingCount = 0;

function get()
{
    fetch("https://fakestoreapi.com/products/").
    then(response => response.text()).
    then(result => 
    {
        currentData = JSON.parse(result);
        currentData.forEach(element => 
        {
            display(element)
        });
    })
}

function display(element)
{
    container.innerHTML += `<div class="item">
                                                                    <div class="item-image-container">
                                                                        <img src="${element.image}" class="item-image">
                                                                    </div>
                                                                    <p class="item-title">${element.title}</p>
                                                                    <p class="item-description">${element.description}</p>
                                                                    <span class="item-category">${element.category}</span>
                                                                    <span class="item-price">${element.price}</span>
                                                                    <div class="item-rating}
                                                                        <span class="item-rating">${element.rating.rate}</span>
                                                                        <span class="item-review-count">${element.rating.count}</span>
                                                                    </div>
                                                                </div>`;
}

function search()
{
    let searchInput = document.getElementById("searchbar").value;
    container.innerHTML = "";
    currentData.forEach(element => 
    {
        if (element.price <= searchInput)
        {
            display(element)
        }
    });

    if (container.innerHTML == "")
    {
        container.innerHTML = "No available products under this price";
    }
}

function averagePrice()
{
    currentData.forEach(element => 
    {
        switch (element.category)
        {
            case "men's clothing":
                mensClothingAveragePrice += element.price;
                mensClothingCount++;
                break;
    
            case "women's clothing":
                womensClothingAveragePrice += element.price;
                womensClothingCount++;
                break;
        }
    })
    mensClothingAveragePrice /= mensClothingCount;
    womensClothingAveragePrice /= womensClothingCount;
    document.getElementById("mens-clothing-average-price").innerHTML = `The average price of men's clothing ${mensClothingAveragePrice}`;
    document.getElementById("womens-clothing-average-price").innerHTML = `The average price of men's clothing ${womensClothingAveragePrice}`;
    document.getElementById("number-of-mens-clothing").innerHTML = `There are ${mensClothingCount} pieces of men's clothing`;
    document.getElementById("number-of-womens-clothing").innerHTML = `There are ${womensClothingCount} pieces of women's clothing`; 
    if (mensClothingAveragePrice > womensClothingAveragePrice) 
    {
        document.getElementById("display-bigger").innerHTML = "Men's Clothing's is more expensive on average"
    }
    else if (womensClothingAveragePrice > mensClothingAveragePrice) 
    {
        document.getElementById("display-bigger").innerHTML = "Women's Clothing's is more expensive on average"
    }
    else
    {
        document.getElementById("display-bigger").innerHTML = "Both genders clothes are the same price on average"
    }
}

function highestRating()
{
    let max = 0
    currentData.forEach(element => 
    {
        if (max < element.rating.rate)
        {
            max = element.rating.rate;
        }
    })
    currentData.forEach(element => 
    {
        if (max == element.rating.rate)
        {
            alert(element.title, element.description, element.price, element.category, element.rating.rate, element.rating.count);
        }
    })
}

function categories()
{
    let mensClothing = 0
    let womensClothing = 0
    let jewelery = 0
    let electronics = 0


    currentData.forEach(element => 
    {
        switch(element.category)
        {
            case "men's clothing":
                mensClothing++;
                break;

            case "women's clothing":
                womensClothing++;
                break;

            case "jewelery":
                jewelery++;
                break;

            case "electronics":
                electronics++;
                break;
        }
    })
    document.getElementById("number-of-items-by-categories").innerHTML = (`men's clothing: ${mensClothing}, women's clothing: ${womensClothing}, jewelery: ${jewelery}, electronics: ${electronics}`)
}
get();
