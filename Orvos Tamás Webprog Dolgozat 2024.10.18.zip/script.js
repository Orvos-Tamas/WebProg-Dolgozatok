let levelInput = document.getElementById("level-input");
let numberOfChestsInput = document.getElementById("number-of-chests-input");
let openChestsButton = document.getElementById("open-chests-button");
let cardsContainer = document.getElementById("cards-container");
let statisticsContainer = document.getElementById("statistics-container");

openChestsButton.addEventListener("click", OpenChests)

function OpenChests()
{
    cardsContainer.innerHTML = '';
    let mimicCount = 0;
    let swordCount = 0;
    let armorCount = 0;
    let resourceCount = 0;
    let sumOfValues = 0;
    let averageOfValues = 0;

    for (let i = 0; i < numberOfChestsInput.value; i++)
    {
        let randomNumber = Math.floor(Math.random() * 10);
        let item;
        let value = 0;
        let damage = 0;
        let defense = 0;

        // switch (randomNumber)
        // {
        //     case 0:
        //         alert("mimic")
        //     case 
        // }
        if (randomNumber == 0)
        {
            mimicCount++;
            item = "Mimic";
            value = levelInput.value * -10;
        }
        else if (randomNumber < 4)
        {
            swordCount++;
            item = "Sword";
            damage = levelInput.value * (Math.floor(Math.random() * 11) + 10);
            value = damage * 100;

            
        }
        else if (randomNumber < 7)
        {
            armorCount++;
            item = "Armor";
            defense = levelInput.value * (Math.floor(Math.random() * 11) + 10);
            value = defense * 100;

        }
        else
        {
            resourceCount++;
            item = "Resource";
            value = levelInput.value * 2;
        }
        sumOfValues += value;
        averageOfValues += value;

        CreateCard(item, value, damage, defense);
    }
    
    averageOfValues /= (swordCount + armorCount + resourceCount);
    DisplayStatistics(mimicCount, swordCount, armorCount, resourceCount, sumOfValues, averageOfValues)
}

function CreateCard(item, value, damage, defense)
{
    cardsContainer.innerHTML += `   <div class="card">
                                        <div class="card-title">${item}</div>
                                        
                                        <div class="card-properties">
                                            Value: ${value} </br>
                                            Damage: ${damage} </br>
                                            Defense: ${defense} </br>
                                        </div>
                                    </div>`;
}

function DisplayStatistics(mimicCount, swordCount, armorCount, resourceCount, sumOfValues, averageOfValues)
{
    statisticsContainer.innerHTML = `Number of items opened:
                                        Mimics: ${mimicCount}
                                        Swords: ${swordCount}
                                        Armors: ${armorCount}
                                        Resources: ${resourceCount}
                                    Sum of the value of items opened: ${sumOfValues}
                                    Average value of items opened: ${Math.round(averageOfValues * 100) / 100}`;
}